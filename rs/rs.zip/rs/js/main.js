'use strict';

(function () {
    $('.service__tab').on('click', function (e) {
        e.preventDefault();
        $(this).closest('.service').toggleClass('active');
    });
})();
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4uanMiXSwibmFtZXMiOlsiJCIsIm9uIiwiZSIsInByZXZlbnREZWZhdWx0IiwiY2xvc2VzdCIsInRvZ2dsZUNsYXNzIl0sIm1hcHBpbmdzIjoiOztBQUFBLENBQUEsWUFBQTtBQUNBQSxNQUFBLGVBQUEsRUFBQUMsRUFBQSxDQUFBLE9BQUEsRUFBQSxVQUFBQyxDQUFBLEVBQUE7QUFDQUEsVUFBQUMsY0FBQTtBQUNBSCxVQUFBLElBQUEsRUFBQUksT0FBQSxDQUFBLFVBQUEsRUFBQUMsV0FBQSxDQUFBLFFBQUE7QUFDQSxLQUhBO0FBSUEsQ0FMQSIsImZpbGUiOiJtYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uKCl7XHJcbiAgICAkKCcuc2VydmljZV9fdGFiJykub24oJ2NsaWNrJywgZnVuY3Rpb24oZSl7XHJcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgICQodGhpcykuY2xvc2VzdCgnLnNlcnZpY2UnKS50b2dnbGVDbGFzcygnYWN0aXZlJyk7XHJcbiAgICB9KTtcclxufSkoKTsiXX0=
